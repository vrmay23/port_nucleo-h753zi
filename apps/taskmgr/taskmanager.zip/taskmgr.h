#ifndef TASKMGR_H
#define TASKMGR_H

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

#define TASKMGR_MAX_TASKS 16
#define TASK_NAME_MAX 32

typedef enum {
    TASK_RUNNING,
    TASK_STOPPED
} task_status_t;

typedef enum {
    TASK_ORDER_PID,
    TASK_ORDER_NAME,
    TASK_ORDER_RUNTIME
} task_order_t;

typedef struct {
    int pid;
    char name[TASK_NAME_MAX];
    size_t stack_size;
    uint32_t runtime_ms;
    task_status_t status;
    void (*stop_cb)(void);
} task_entry_t;

int taskmgr_register(int pid, const char *name, size_t stack_size, void (*stop_cb)(void));
int taskmgr_unregister(int pid);
int taskmgr_stop(int pid);
void taskmgr_list(task_order_t order, bool ascending);

#endif // TASKMGR_H

