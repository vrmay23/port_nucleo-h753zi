#include "taskmgr.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <inttypes.h>

/* Inicializa explicitamente com zeros */
static task_entry_t g_tasks[TASKMGR_MAX_TASKS] = {{0}};
static int g_task_count = 0;

/* Função de comparação personalizada para sorting manual */
static int task_compare(const task_entry_t *t1, const task_entry_t *t2, task_order_t order)
{
    switch (order)
    {
        case TASK_ORDER_PID:
            return t1->pid - t2->pid;
        case TASK_ORDER_NAME:
            return strcmp(t1->name, t2->name);
        case TASK_ORDER_RUNTIME:
            return (int)(t1->runtime_ms - t2->runtime_ms);
        default:
            return 0;
    }
}

/* Implementação manual de bubble sort (simples e compatível) */
static void task_sort(task_entry_t *tasks, int count, task_order_t order, bool ascending)
{
    for (int i = 0; i < count - 1; i++)
    {
        for (int j = 0; j < count - 1 - i; j++)
        {
            int cmp = task_compare(&tasks[j], &tasks[j + 1], order);
            
            if (ascending ? (cmp > 0) : (cmp < 0))
            {
                task_entry_t tmp = tasks[j];
                tasks[j] = tasks[j + 1];
                tasks[j + 1] = tmp;
            }
        }
    }
}

int taskmgr_register(int pid, const char *name, size_t stack_size, void (*stop_cb)(void))
{
    if (g_task_count >= TASKMGR_MAX_TASKS || name == NULL)
    {
        return -1;
    }

    task_entry_t *t = &g_tasks[g_task_count++];
    t->pid = pid;
    strncpy(t->name, name, TASK_NAME_MAX - 1);
    t->name[TASK_NAME_MAX - 1] = '\0';
    t->stack_size = stack_size;
    t->runtime_ms = 0;
    t->status = TASK_RUNNING;
    t->stop_cb = stop_cb;
    return 0;
}

int taskmgr_unregister(int pid)
{
    for (int i = 0; i < g_task_count; i++)
    {
        if (g_tasks[i].pid == pid)
        {
            /* Move todos os elementos para a esquerda */
            for (int j = i; j < g_task_count - 1; j++)
            {
                g_tasks[j] = g_tasks[j + 1];
            }
            g_task_count--;
            return 0;
        }
    }
    return -1;
}

int taskmgr_stop(int pid)
{
    for (int i = 0; i < g_task_count; i++)
    {
        if (g_tasks[i].pid == pid)
        {
            if (g_tasks[i].stop_cb)
            {
                g_tasks[i].stop_cb();
            }
            
            /* Evita usar kill() que pode causar panic - apenas marca como stopped */
            g_tasks[i].status = TASK_STOPPED;
            printf("Task %d marked as stopped (kill not implemented safely)\n", pid);
            return 0;
        }
    }
    return -1;
}

void taskmgr_list(task_order_t order, bool ascending)
{
    printf("Task Manager - Total registered tasks: %d\n", g_task_count);
    
    if (g_task_count == 0)
    {
        printf("No tasks registered. This is a demo system.\n");
        printf("Use 'ps' command to see actual system tasks.\n");
        return;
    }

    /* Cria cópia para ordenação */
    task_entry_t sorted[TASKMGR_MAX_TASKS];
    memcpy(sorted, g_tasks, g_task_count * sizeof(task_entry_t));

    /* Ordena usando algoritmo simples */
    task_sort(sorted, g_task_count, order, ascending);

    printf("# | PID | NAME                | SIZE   | RUNTIME | STATUS\n");
    printf("--+-----+---------------------+--------+---------+--------\n");

    for (int i = 0; i < g_task_count; i++)
    {
        printf("%2d | %3d | %-19s | %6zu | %7"PRIu32" | %s\n",
               i + 1,
               sorted[i].pid,
               sorted[i].name,
               sorted[i].stack_size,
               sorted[i].runtime_ms,
               (sorted[i].status == TASK_RUNNING ? "RUNNING" : "STOPPED"));
    }
    
    printf("\nNOTE: This is a demo task manager. For real system tasks use 'ps'.\n");
}
